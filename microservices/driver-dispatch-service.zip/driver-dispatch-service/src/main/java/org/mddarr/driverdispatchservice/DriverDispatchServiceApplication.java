package org.mddarr.driverdispatchservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriverDispatchServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DriverDispatchServiceApplication.class, args);
	}

}
