package org.mddarr.ridereceiver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RideReceiverApplicationTests {

	@Test
	void contextLoads() {
	}

}
